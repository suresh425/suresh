import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class UploadsingleService {

  constructor(private http:HttpClient) { }
  getAllProductDetails(){
    return this.http.get("http://localhost:9096/view");
 }

 addproduct(data:any){
 
  let input=new FormData();
  input.append("productId",data.id);
  input.append("productName",data.name);
  input.append("cost",data.cost); 
  input.append("countryOrigin",data.origin);
  return this.http.post("http://localhost:9096/insertdata/single",input);
}


}
