import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-singleload',
  templateUrl: './singleload.component.html',
  styleUrls: ['./singleload.component.css']
})
export class SingleloadComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
