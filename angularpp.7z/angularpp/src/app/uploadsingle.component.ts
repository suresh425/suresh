import { Component, OnInit } from '@angular/core';
import { UploadsingleService } from './uploadsingle.service';

@Component({
  selector: 'app-uploadsingle',
  templateUrl: './uploadsingle.component.html',
  styleUrls: ['./uploadsingle.component.css']
})
export class UploadsingleComponent implements OnInit {
  model:any={};
 
  constructor(private service:UploadsingleService) { }

  ngOnInit() {
    
  }
  addproduct():any{

   this.service.addproduct(this.model).subscribe();
  }
}
