import { Component, OnInit } from '@angular/core';
import { UploadsingleService } from './uploadsingle.service';
import  {Router}from  '@angular/router'
import { ProjectService } from 'src/app/project.service';
@Component({
  selector: 'app-viewdata',
  templateUrl: './viewdata.component.html',
  styleUrls: ['./viewdata.component.css']
})
export class ViewdataComponent implements OnInit {
  model:any={};
  selected:boolean=false;
  constructor(private router:Router,private service:ProjectService) { }
  productdata:any[]=[];
  productcategory:any[]=[];
  ngOnInit() {

    this.service.getProductDetails().subscribe((data:any)=>this.productdata=data);
    this.service.getProductCategoryDetails().subscribe((data:any)=>this.productcategory=data)
  }

  select(){
    this.selected=true;
     }
}
