import { Component, OnInit } from '@angular/core';
import { ProjectService } from 'src/app/project.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-forgotpassword1',
  templateUrl: './forgotpassword1.component.html',
  styleUrls: ['./forgotpassword1.component.css']
})
export class Forgotpassword1Component implements OnInit {
  searchterm:any;
  userDetails:any;
  flag1:any;
  flag2:any;
  flag3:any;
  flag4:any;
  flag5:any;
 
  Securityquestion:any;
  constructor(private service:ProjectService,private router:Router) {

   
   }

  ngOnInit() {
  }
  search(){
    this.flag1=false;
    this.Securityquestion=null;
    this.flag2=false;
    console.log(this.searchterm);
   
    this.service.search(this.searchterm).subscribe((data)=>{this.userDetails=data;
      if(this.userDetails){
        this.flag2=true;
          console.log(this.userDetails);
         this.Securityquestion= this.userDetails.securityQuestion
         console.log(this.flag2);
      }
      else{
        this.flag1=true;
      }});
     // this.service.search(this.searchterm).subscribe((data))

  }
  onSubmit(userForm){
    this.flag3=false;
    this.flag5=false;
    this.flag4=false;
  //  {serialNo: 18, userName: "megana", password: "megana", securityQuestion: "What do u do in free time?", answer: "kasab"}
  if(userForm.password==userForm.confirmpassword) {
    this.flag3=false;
    let input= {"serialNo":this.userDetails.serialNo,"userName":this.userDetails.userName,"password":userForm.password,"securityQuestion":this.userDetails.securityQuestion,"answer":userForm.answer}; 
    this.service.update(input).subscribe((data)=>{this.flag4=data;
    if(this.flag4){}else{this.flag5=true}})
    //console.log(input);
  } 
  else{
    this.flag3=true;
  }
 
  }

}
