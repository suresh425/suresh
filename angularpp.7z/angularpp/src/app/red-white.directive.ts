import { Directive, ElementRef } from '@angular/core';

@Directive({
  selector: '[appRedWhite]',
  
})
export class RedWhiteDirective {

  constructor(private el:ElementRef) {
    this.el.nativeElement.style.color="white";
    this.el.nativeElement.style.backgroundColor="red";
   }

}
