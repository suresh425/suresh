import { Component, OnInit } from '@angular/core';
import { ProjectService } from 'src/app/project.service';

@Component({
  selector: 'app-uploadbulk',
  templateUrl: './uploadbulk.component.html',
  styleUrls: ['./uploadbulk.component.css']
})
export class UploadbulkComponent implements OnInit {

  title = 'filedemo';
  file:File;
  selected:boolean=false;
  selectedFiles: FileList;
  currentFileUpload: File;
  tables:any[]=[];
  constructor(private service:ProjectService) { }

  ngOnInit() {

    this.service.getTables().subscribe((data)=>this.tables=data);
  }
  selectFile(event) {
    this.selectedFiles = event.target.files;
  } 
 
  upload() {
    console.log("ts"+this.selectedFiles);
    this.currentFileUpload = this.selectedFiles.item(0);
    this.service.uploadProduct(this.currentFileUpload).subscribe(event => {
     
   });
    this.selectedFiles = undefined;
  }
  uploaddetails() {
    console.log("ts"+this.selectedFiles);
    this.currentFileUpload = this.selectedFiles.item(0);
    this.service.uploadDetails(this.currentFileUpload).subscribe(event => {
     
   });
    this.selectedFiles = undefined;
  }
  select(){
    this.selected=true;
     }
}
