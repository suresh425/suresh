import { Component, OnInit } from '@angular/core';
import { ProjectService } from 'src/app/project.service';

@Component({
  selector: 'app-modifyfields',
  templateUrl: './modifyfields.component.html',
  styleUrls: ['./modifyfields.component.css']
})
export class ModifyfieldsComponent implements OnInit {

  constructor(private service:ProjectService) { }
  productdata:any[]=[];
  productcategory:any[]=[];
  model:any={};
  selected:boolean=false;
  table1:any;
  table2:any;

  ngOnInit() {
    this.service.getProductDetails().subscribe((data:any)=>this.productdata=data);
    this.service.getProductCategoryDetails().subscribe((data:any)=>this.productcategory=data);
    this.service.getProductCategoryDetails().subscribe((data:any)=>console.log(data));
  }
select(){
        this.selected=true;
         }
}
