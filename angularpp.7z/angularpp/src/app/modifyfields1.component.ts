import { Component, OnInit } from '@angular/core';
import { ProjectService } from 'src/app/project.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-modifyfields1',
  templateUrl: './modifyfields1.component.html',
  styleUrls: ['./modifyfields1.component.css']
})
export class Modifyfields1Component implements OnInit {

  modifyobj:any={};
  
    model:any={}
    constructor(private service:ProjectService, private activatedRoute:ActivatedRoute) { }
  
    ngOnInit() {
      let obj=this.activatedRoute.snapshot.params['id'];
      this.service.getById(obj).subscribe((data:any)=>this.modifyobj=data);
      
    }
    update():any{
      console.log(this.modifyobj);
     /*productId: "7", productName: "ehtds", cost: "656", countryOrigin: "fdhdsh", expiryDate: "2019-08-16"*/
     /*  {productId: 888888, productName: "mmmmm",*/
       
   //console.log(this.model);
      /*console.log(this.modifyobj);
      console.log(this.model.productName); */
      if(this.model.productName==undefined){
        console.log("inside iff");
       this.model.productName=this.modifyobj.productName;
       
      }
      if(this.model.productId==undefined){
      this.model.productId=this.modifyobj.productId;
       
      }
      if(this.model.cost==undefined){
      this.model.cost=this.modifyobj.cost;
       
      }
      if(this.model.countryOrigin==undefined){
      this.model.countryOrigin=this.modifyobj.countryOrigin;
       
      }
      if(this.model.expiryDate==undefined){
        this.model.expiryDate=this.modifyobj.expiryDate;
       
       }
      console.log(this.model);
      this.service.updateproduct(this.model).subscribe();
     
    }
  


}
