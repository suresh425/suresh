import { Component, OnInit } from '@angular/core';
import { ProjectService } from 'src/app/project.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-modifyfields2',
  templateUrl: './modifyfields2.component.html',
  styleUrls: ['./modifyfields2.component.css']
})
export class Modifyfields2Component implements OnInit {

  modifyobj:any={};
  
    model:any={};
  constructor(private service:ProjectService, private activatedRoute:ActivatedRoute) { }

  ngOnInit() {
    let obj=this.activatedRoute.snapshot.params['id'];
    this.service.getById1(obj).subscribe((data:any)=>this.modifyobj=data);
 
   
    
  }
 /* productionId: "8", 
  prodName: "fjd", prodDescription: "fgdj", dealerName: "fhdty", dealerAddress: "teyrgfes"*/

  update():any{
    console.log(this.modifyobj);
   /*productId: "7", productName: "ehtds", cost: "656", countryOrigin: "fdhdsh", expiryDate: "2019-08-16"*/
   /*  {productId: 888888, productName: "mmmmm",*/
     
 //console.log(this.model);
    /*console.log(this.modifyobj);
    console.log(this.model.productName); */
    if(this.model.prodName==undefined){
      console.log("inside iff");
     this.model.prodName=this.modifyobj.prodName;
     
    }
    if(this.model.productionId==undefined){
    this.model.productionId=this.modifyobj.productionId;
     
    }
    if(this.model.prodDescription==undefined){
    this.model.prodDescription=this.modifyobj.prodDescription;
     
    }
    if(this.model.dealerName==undefined){
    this.model.dealerName=this.modifyobj.dealerName;
     
    }
    if(this.model.dealerAddress==undefined){
      this.model.dealerAddress=this.modifyobj.dealerAddress;
     
     }
    console.log(this.model);
    this.service.updateproductCategory(this.model).subscribe();
   
  }

}
