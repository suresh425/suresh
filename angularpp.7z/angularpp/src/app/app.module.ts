import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {ReactiveFormsModule} from '@angular/forms';
 import {FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { Democomponent } from './demo.component';
import { RedWhiteDirective } from './red-white.directive';
import { TemplateFormComponent } from './forms/template-form.component';
import { ModelFormComponent } from './forms/model-form.component';
import { TemplateFormLabComponent } from './forms/template-form-lab.component';
import { ProductloginComponent } from './productlogin.component';
import { SignupComponent } from './signup.component';
import { HomeComponent } from './home.component';
import { SingleloadComponent } from './singleload.component';
import { UploadsingleComponent } from './uploadsingle.component';
import {HttpClientModule} from '@angular/common/http';
import { ViewdataComponent } from './viewdata.component';
import { SinglefieldComponent } from './singlefield.component';
import { ModifyfieldsComponent } from './modifyfields.component';
import { Modifyfields1Component } from './modifyfields1.component';
import { DeleteComponent } from './delete.component';
import { DeletebulkComponent } from './deletebulk.component';
import { LogoutComponent } from './logout.component';
import { ForgotpasswordComponent } from './forgotpassword.component';
import { Forgotpassword1Component } from './forgotpassword1/forgotpassword1.component';
import { LoadSingleComponent } from './load-single/load-single.component';
import { Modifyfields2Component } from './modifyfields2.component';
import { UploadbulkComponent } from './uploadbulk.component';

@NgModule({
  declarations: [
    AppComponent,Democomponent, RedWhiteDirective, TemplateFormComponent, ModelFormComponent, TemplateFormLabComponent, ProductloginComponent, SignupComponent, HomeComponent, SingleloadComponent, UploadsingleComponent, ViewdataComponent,
    SinglefieldComponent,ModifyfieldsComponent,Modifyfields1Component,DeleteComponent, 
    DeletebulkComponent,LogoutComponent, ForgotpasswordComponent, Forgotpassword1Component, LoadSingleComponent, Modifyfields2Component, UploadbulkComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,FormsModule,ReactiveFormsModule,HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
