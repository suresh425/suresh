import { Component, OnInit } from '@angular/core';
import { ProjectService } from 'src/app/project.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-load-single',
  templateUrl: './load-single.component.html',
  styleUrls: ['./load-single.component.css']
})
export class LoadSingleComponent implements OnInit {

  selected: boolean = false;
  table1: any;
  table2: any;
  product: any = {};
  productDetails: any = {};
  tables: any[] = [];
  constructor(private service: ProjectService, private router: Router) {

  }

  ngOnInit() {
    this.service.getTables().subscribe((data) => this.tables = data);
    this.service.getTables().subscribe((data) => console.log(data));
  }

  onSubmit(userForm) {

    this.table1 = false;
    this.table2 = false;

    if (userForm.table == "ProductDetails") {
      this.table1 = true;
    }

    if (userForm.table == "ProductCategory") {
      this.table2 = true;
    }
    if (userForm.table == "product") {
      this.table1 = true;
    }
    if (userForm.table == "product_details") {
      this.table2 = true;
    }

  }
  addproduct() {

    this.service.addProduct(this.product).subscribe();
    this.router.navigate(["./view"]);
  }
  addproductDetails() {
    this.service.addProductDetails(this.productDetails).subscribe();
    this.router.navigate(["./view"]);
  }

  select() {
    this.selected = true;
  }

}


