import { Component, OnInit } from '@angular/core';
import {FormGroup, FormControl,Validators} from '@angular/forms';

@Component({
  selector: 'app-template-form-lab',
  templateUrl: './template-form-lab.component.html',
  styleUrls: ['./template-form-lab.component.css']
})
export class TemplateFormLabComponent implements OnInit {
  userForm:FormGroup;

  constructor() { 
    this.userForm=new FormGroup({
      id:new FormControl(null,[Validators.required]),
      name:new FormControl(null,[ Validators.required]),
      cost:new FormControl(null,[Validators.required]),
      online:new FormControl(null,[Validators.required]),
      
    })
  }

  ngOnInit() {
  }
  onSubmit(value){
    console.log(value);
  }

}
