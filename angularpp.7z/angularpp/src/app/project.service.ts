import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class ProjectService {

  constructor(private http:HttpClient,private router:Router) { }

  signUp(data){
    let input= {"userName":data.uname,"password":data.password,"securityQuestion":data.question,"answer":data.answer};
    console.log(input);
    return this.http.post("http://localhost:9858/user/signup",input);
  }
  login(data){
  let input={"userName":data.uname,"password":data.password}
  //console.log(input);
  return this.http.get("http://localhost:9858/user/login?username="+input.userName+"&password="+input.password);
  }

  search(data){
    return this.http.get("http://localhost:9858/user/findUser1?username="+data)
  }
  update(data){
    return this.http.put("http://localhost:9858/user/updatepassword",data)
  }

  addProduct(data){
    console.log(data)
    return this.http.post("http://localhost:9858/Product/insertdata/single",data);
  }

  addProductDetails(data){
    //console.log(data);
    return this.http.post("http://localhost:9858/ProductDetails/insertdetails/single",data);
  }
  getProductDetails()
  {
    return this.http.get("http://localhost:9858/Product/view")
  }
  getProductCategoryDetails()
  {
    return this.http.get("http://localhost:9858/ProductDetails/viewDetails")
  }
  deleteProduct(product){
    return this.http.delete("http://localhost:9858/Product/delete/?pid="+product);
  }
  deleteProductCategory(product){
    return this.http.delete("http://localhost:9858/ProductDetails/deleteDetails/?pid="+product);
    //this.router.navigate(["./view"]);
  }
  getById(model)
  {
    return this.http.get("http://localhost:9858/Product/viewbyid/?pid="+model);
  }
  getById1(model)
  {
    return this.http.get("http://localhost:9858/ProductDetails/viewbyidDetails/?pid="+model);
  }

  updateproduct(data:any)
  {
    let input={
      "productId":data.productId,"productName":data.productName,"cost":data.cost ,"countryOrigin":data.countryOrigin,"expiryDate":data.expiryDate};
      
       return this.http.post("http://localhost:9858/Product/update",input);
  }

  updateproductCategory(data:any)
  {
    let input={
      "productId":data.productId,"productName":data.productName,"cost":data.cost ,"countryOrigin":data.countryOrigin,"expiryDate":data.expiryDate};
      
       return this.http.post("http://localhost:9858/ProductDetails/updateDetails",data);
  }

  getAllProductDetails(){
    return this.http.get("http://localhost:9858/ProductDetails/viewDetails");
 }

 
uploadProduct(file:File):Observable<any>
{

    console.log(file);
    const input=new FormData();
    input.append('file',file);
    return this.http.post("http://localhost:9858/Product/insertdata/bulk",input,{
      reportProgress: true,
      responseType: 'text'
    });
}

uploadDetails(file:File):Observable<any>
{

    console.log(file);
    const input=new FormData();
    input.append('file',file);
    return this.http.post("http://localhost:9858/ProductDetails/insertdata/bulk",input,{
      reportProgress: true,
      responseType: 'text'
    });
}

getTables(){
  return this.http.get("http://localhost:9858/Product/selectedtable");
}

}
