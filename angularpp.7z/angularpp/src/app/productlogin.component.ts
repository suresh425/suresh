import { Component, OnInit } from '@angular/core';
import { Router } from '../../node_modules/@angular/router';
import { ProjectService } from 'src/app/project.service';

@Component({
  selector: 'app-productlogin',
  templateUrl: './productlogin.component.html',
  styleUrls: ['./productlogin.component.css']
})
export class ProductloginComponent implements OnInit {
  
  constructor(private router:Router,private service1:ProjectService) { }
 
  ngOnInit() {
  }
 
  flag:any;
  result:boolean;
   onSubmit(userForm){
     this.flag=false;
   // console.log(userForm)
   //let result:boolean;
   let result1:any;
    this.service1.login(userForm).subscribe((data:boolean)=>{this.result=data;
    if(this.result){
      this.router.navigate(['./home'])}
    else{
        this.flag=true;
    }}
   );
  
 
  //this.service.login(userForm).subscribe((data)=>console.log(data));
  

/* if(this.result){
  this.router.navigate(['./home']);
} */
 
  } 

}
