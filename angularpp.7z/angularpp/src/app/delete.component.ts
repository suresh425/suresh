import { Component, OnInit } from '@angular/core';
import { ProjectService } from 'src/app/project.service';
import { Router } from '@angular/router'
@Component({
  selector: 'app-delete',
  templateUrl: './delete.component.html',
  styleUrls: ['./delete.component.css']
})
export class DeleteComponent implements OnInit {
  selected: boolean = false;
  selectedIDs: any[] = [];
  productdata: any[] = [];
  productcategory: any[] = [];

  constructor(private router: Router, private service: ProjectService) { }

  ngOnInit() {
    // this.service.getAllProductDetails().subscribe((data:any)=>this.productdata=data);
    this.service.getProductDetails().subscribe((data: any) => this.productdata = data);
    this.service.getProductCategoryDetails().subscribe((data: any) => this.productcategory = data)
  }
  select() {

    this.selected = true;
  }


  onDeleteDetails(p) {
    /* let a=this.productdata.indexOf(p);
    this.productdata.splice(a,1);  */
    this.service.deleteProduct(p).subscribe();
    this.router.navigate(['./view']);

  }
  onDeleteCategory(p) {
    /*  let a=this.productcategory.indexOf(p);
    this.productcategory.splice(a,1);  */
    this.service.deleteProductCategory(p).subscribe();
    this.router.navigate(["./view"]);

  }

}
