import { Component, OnInit } from '@angular/core';
import { ProjectService } from 'src/app/project.service';
import { Router } from '@angular/router'
@Component({
  selector: 'app-deletebulk',
  templateUrl: './deletebulk.component.html',
  styleUrls: ['./deletebulk.component.css']
})
export class DeletebulkComponent implements OnInit {
  productdata: any[] = [];
  productcategory: any[] = [];
  selectedIDs: any[] = [];
  selected: boolean = false;
  constructor(private router: Router, private service: ProjectService) { }

  ngOnInit() {
    this.service.getProductDetails().subscribe((data: any) => this.productdata = data);
    this.service.getProductCategoryDetails().subscribe((data: any) => this.productcategory = data);
  }
  selectID(id, event: any) {
    this.selectedIDs.push(id);
    console.log(this.selectedIDs);
  }

  deleteselected() {

    for (var i = 0; i < this.selectedIDs.length; i++) {
      this.service.deleteProduct(this.selectedIDs[i]).subscribe();
    }
    this.router.navigate(["./view"]);
  }

  select() {

    this.selected = true;
  }
  deleteproduct() {


    for (var i = 0; i < this.selectedIDs.length; i++) {
      this.service.deleteProductCategory(this.selectedIDs[i]).subscribe();
      console.log("delete")
    }
    console.log("delete")

  }
  deleteview() {

  }
}
