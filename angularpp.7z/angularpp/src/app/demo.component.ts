import { Component } from "@angular/core";

@Component({
    selector:"app1-demo",
    template:`<h1>Hello World</h1>`,
    styleUrls:['./demo.component.css']

})
export class Democomponent{

}