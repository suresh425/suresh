import { Component, OnInit } from '@angular/core';
import { ProjectService } from 'src/app/project.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  constructor(private service:ProjectService,private router:Router) { }
  check:boolean;
  flag:any;
  flag1:any;
  ngOnInit() {
  }
  onSubmit(userForm){
    this.flag=false;
    this.flag1=false;
    this.check=true;
    this.service.signUp(userForm).subscribe((data)=>{this.flag=data;
    if(this.flag){}
  else{
    this.flag1=true;
  }});
  this.router.navigate(["./login"]);
    
  }
}
