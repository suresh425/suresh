import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-singlefield',
  templateUrl: './singlefield.component.html',
  styleUrls: ['./singlefield.component.css']
})
export class SinglefieldComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
