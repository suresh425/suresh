import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProductloginComponent } from './productlogin.component';
import { SignupComponent } from './signup.component';
import { HomeComponent } from './home.component';
import { SingleloadComponent } from './singleload.component';
import { UploadsingleComponent } from './uploadsingle.component';
import { ViewdataComponent } from './viewdata.component';
import { SinglefieldComponent } from './singlefield.component';
import { ModifyfieldsComponent } from './modifyfields.component';
import { Modifyfields1Component } from './modifyfields1.component';
import { DeleteComponent } from './delete.component';
import { DeletebulkComponent } from './deletebulk.component';
import { LogoutComponent } from './logout.component';
import { ForgotpasswordComponent } from './forgotpassword.component';
import { Forgotpassword1Component } from 'src/app/forgotpassword1/forgotpassword1.component';
import { LoadSingleComponent } from 'src/app/load-single/load-single.component';
import { Modifyfields2Component } from 'src/app/modifyfields2.component';
import { UploadbulkComponent } from 'src/app/uploadbulk.component';

const routes: Routes = [{path:'login',component:ProductloginComponent},
{path:'forgotpassword',component:ForgotpasswordComponent},
{path:'signup',component:SignupComponent},
{path:'home',component:HomeComponent},
//{path:'singleload',component:SinglefieldComponent},
{path:'upload',component:UploadsingleComponent},
{path:'view',component:ViewdataComponent},
{path:'modify',component:ModifyfieldsComponent},
{path:'modifyfields1/:id',component:Modifyfields1Component},
{path:'delete',component:DeleteComponent},
{path:'deletebulk',component:DeletebulkComponent},
{path:'logout',component:LogoutComponent},
{path:'singleload',component:LoadSingleComponent},
{path:'uploadbulk',component:UploadbulkComponent},
{path:'',redirectTo:'/login',pathMatch:'full'},
{path:'forgot',component:Forgotpassword1Component},
{path:'modifyfields2/:id',component:Modifyfields2Component}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
